int main(int argc, char** argv) {
  return 42 << 0 + 2 >> 1 * 2;
}