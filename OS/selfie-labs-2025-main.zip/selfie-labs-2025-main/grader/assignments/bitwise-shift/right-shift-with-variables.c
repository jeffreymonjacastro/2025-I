int main(int argc, char** argv) {
  uint64_t a;
  uint64_t b;

  a = 84;
  b = 1;

  return a >> b;
}