uint64_t lr(uint64_t address);

int main(int argc, char** argv) {
  return (int) lr(0);
}