uint64_t sc(uint64_t address, uint64_t value);

int main(int argc, char** argv) {
  return (int) sc(0, 1);
}