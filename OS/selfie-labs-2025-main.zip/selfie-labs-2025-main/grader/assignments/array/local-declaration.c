int main(int argc, char** argv) { 
  uint64_t a[2];
}