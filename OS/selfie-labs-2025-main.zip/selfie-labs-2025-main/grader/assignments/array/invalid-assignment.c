uint64_t a[2];

int main(int argc, char** argv) {
  a = 2;
}