int main(int argc, char** argv) {
  uint64_t a;
  uint64_t b;

  a = 40;
  b = 34;

  return a | b;
}