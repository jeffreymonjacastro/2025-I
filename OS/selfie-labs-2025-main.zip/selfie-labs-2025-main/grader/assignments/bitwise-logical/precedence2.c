int main(int argc, char** argv) {
  return 42 - 0 & ~((uint64_t)18446744073709551573) + 1 | 42;
}