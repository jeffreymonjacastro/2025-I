int main(int argc, char** argv) {
  return 43 & 58;
}