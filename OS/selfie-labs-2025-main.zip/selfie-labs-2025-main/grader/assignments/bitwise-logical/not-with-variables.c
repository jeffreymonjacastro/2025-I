int main(int argc, char** argv) {
  uint64_t a;

  a = ~((uint64_t)18446744073709551573);

  return a;
}