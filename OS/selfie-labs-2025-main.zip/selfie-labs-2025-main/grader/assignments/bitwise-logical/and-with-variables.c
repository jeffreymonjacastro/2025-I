int main(int argc, char** argv) {
  uint64_t a;
  uint64_t b;

  a = 43;
  b = 58;

  return a & b;
}