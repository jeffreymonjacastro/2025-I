int main(int argc, char** argv) {
  if (0xFFFFFFFFFFFFFFFF == 18446744073709551615)
    return 42;
  else
    return 0;
}