struct empty_struct { };

int main(int argc, char** argv) { }