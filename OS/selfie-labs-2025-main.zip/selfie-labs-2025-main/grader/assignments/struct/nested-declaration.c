struct nested_struct {
  struct nested_struct* another_struct;
  uint64_t member;
};

int main(int argc, char** argv) { }