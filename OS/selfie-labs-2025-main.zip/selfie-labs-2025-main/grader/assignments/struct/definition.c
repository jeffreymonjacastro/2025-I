struct empty_struct { };

struct empty_struct* global_struct;

int main(int argc, char** argv) {
  struct empty_struct* local_struct;
}