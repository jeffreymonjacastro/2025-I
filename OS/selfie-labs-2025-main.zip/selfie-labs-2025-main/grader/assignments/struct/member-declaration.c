struct trivial_struct {
  uint64_t member;
  uint64_t* pointer;
};

int main(int argc, char** argv) { }