int main(int argc, char* argv) {
  write(1, "Hello World!    ", 16);
  write(1, "Hello World!    ", 16);
  write(1, "HelloHelloHello ", 16);
  write(1, "  WorldWorldWorl", 16);
  write(1, "!!d!            ", 16);
  write(1, "Hello World!    ", 16);
  write(1, "Hello World!    ", 16);
  write(1, "Hello World!    ", 16);
  write(1, "Hello World!    ", 16);
  write(1, "Hello World!    ", 16);
}
