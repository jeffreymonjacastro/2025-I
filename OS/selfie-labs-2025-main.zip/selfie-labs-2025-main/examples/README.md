# C\* Code Examples

The code in this directory showcases selfie's programming language C\*. See selfie's Makefile for more details on how to build the examples.