int main()
{
    uint64_t n;
    uint64_t a;
    uint64_t b;
    uint64_t c;
    a = 23;
    b = 11;
    c = a+b;
    n = tick();
    exit(n);
}