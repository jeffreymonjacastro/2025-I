uint64_t x;
uint64_t y;

uint64_t main() {
  x = 1;
  y = 0;

  x = x / y;
}