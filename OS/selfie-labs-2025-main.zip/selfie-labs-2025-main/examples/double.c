int double(int n) {
  return n + n;
}

int main() {
  return double(42);
}