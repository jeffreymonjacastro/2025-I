# Homework Assignments

The markdown files in this directory feature [introductory](introductory-assignments.md) homework assignments as well as autograded [compiler](compiler-assignments.md) and [systems](systems-assignments.md) assignments. See the autograder's [README.md](../grader/README.md) for instructions on how to run the autograder.