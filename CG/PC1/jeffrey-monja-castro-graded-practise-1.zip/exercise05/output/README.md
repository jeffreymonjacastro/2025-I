## Aplying filters to Lenna

To see the html page with the filters applied, click this [link to deployed page](https://jeffreymonjacastro.github.io/image-filters/) or open the **index file** on `web/index.html` in your browser.

The web page repository is [here](https://github.com/jeffreymonjacastro/image-filters) if you want to see the code.

Made with ❤️ by Jeffrey Monja Castro :D © 2025
