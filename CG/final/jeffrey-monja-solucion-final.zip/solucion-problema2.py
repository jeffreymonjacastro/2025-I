import cv2
import numpy as np
import time
from collections import deque

def solve_maze(path_input_image: str, path_output_image: str):
    start_time = time.time()
    image = cv2.imread(path_input_image)
    if image is None:
        raise ValueError(f"No se pudo leer la imagen: {path_input_image}")

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    wall_threshold = 80
    binary = (gray > wall_threshold).astype(np.uint8)

    height, width = binary.shape

    # Buscar todos los puntos de entrada/salida en los bordes
    border_points = []
    for x in range(width):
        if binary[0, x] == 1:
            border_points.append((0, x))
        if binary[height-1, x] == 1:
            border_points.append((height-1, x))
    for y in range(height):
        if binary[y, 0] == 1:
            border_points.append((y, 0))
        if binary[y, width-1] == 1:
            border_points.append((y, width-1))
    border_points = list(dict.fromkeys(border_points))

    if len(border_points) < 2:
        raise ValueError("No se encontraron suficientes puntos de entrada/salida en los bordes")

    # Probar todos los pares de puntos de borde
    path = None
    for i in range(len(border_points)):
        for j in range(len(border_points)):
            if i == j:
                continue
            candidate_path = bfs_shortest_path(binary, border_points[i], border_points[j])
            if candidate_path is not None and len(candidate_path) > 1:
                path = candidate_path
                print(f"Camino encontrado entre {border_points[i]} y {border_points[j]}, longitud: {len(path)}")
                break
        if path is not None:
            break

    if path is None:
        raise ValueError("No se encontró un camino válido entre entrada y salida")

    output_bgr = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    for y, x in path:
        output_bgr[y, x] = [0, 0, 255]

    cv2.imwrite(path_output_image, output_bgr)
    elapsed_time = time.time() - start_time
    print(f"Tiempo de ejecución: {elapsed_time:.2f} segundos")
    print(f"Imagen guardada en: {path_output_image}")

def bfs_shortest_path(binary, start, end):
    height, width = binary.shape
    directions = [(-1,0), (1,0), (0,-1), (0,1)]
    queue = deque([(start[0], start[1], [start])])
    visited = set()
    visited.add(start)
    while queue:
        y, x, path = queue.popleft()
        if (y, x) == end:
            return path
        for dy, dx in directions:
            ny, nx = y + dy, x + dx
            if 0 <= ny < height and 0 <= nx < width:
                if binary[ny, nx] == 1 and (ny, nx) not in visited:
                    visited.add((ny, nx))
                    queue.append((ny, nx, path + [(ny, nx)]))
    return None

def test_maze_solver():
    input_path = "maze.png"
    output_path = "maze_solved.png"
    
    print("Resolviendo laberinto...")
    start_time = time.time()
    
    try:
        result = solve_maze(input_path, output_path)
        elapsed_time = time.time() - start_time
        
        print(f"Laberinto resuelto exitosamente!")
        print(f"Tiempo de ejecución: {elapsed_time:.4f} segundos")
        print(f"Resultado guardado en: {output_path}")
        
        return True
        
    except Exception as e:
        print(f"Error al resolver el laberinto: {e}")
        return False

if __name__ == "__main__":
    test_maze_solver() 