#include "solution.h"

int main() {
  cube_with_triangular_faces(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0, "cube-triangles.ply");
  return 0;
}
