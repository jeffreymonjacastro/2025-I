#include "solution.h"

int main() {
  cube_with_square_faces(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0, "cube-squares.ply");
  return 0;
}
